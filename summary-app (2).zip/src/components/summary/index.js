import React from 'react';
import SummaryBox from './SummaryBox';

class Summary extends React.Component {
    render() {
        return <SummaryBox />;
    }
}

export default Summary;
