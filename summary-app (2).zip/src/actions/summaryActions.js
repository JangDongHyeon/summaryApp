import axios from 'axios';
import {
    SUMMARY_REQUEST,
    SUMMARY_ERROR
} from './types';

//요약 보내기
export const summaryRequest = data => async dispatch => {
    try {
        let language = data.language;
        let text = data.text;
        let response;

        if (language === 'kr') {
            let formKorea1 = new FormData();
            formKorea1.append('String', text);
            formKorea1.append('ori', 'kr');
            formKorea1.append('tar', 'en');
            response = await axios.post('https://chat.neoali.com:8072/translate', formKorea1);

            text = response.data

        }
        let form = new FormData();
        form.append('String', text);
        response = await axios.post(`https://chat.neoali.com:8072/summary_short`, form);
        if (language === 'kr') {
            let formKorea2 = new FormData();
            formKorea2.append('String', text);
            formKorea2.append('ori', 'en');
            formKorea2.append('tar', 'kr');
            response = await axios.post('https://chat.neoali.com:8072/translate', formKorea2)

        }
        dispatch({
            type: SUMMARY_REQUEST,
            payload: response.data
        });
    } catch (error) {
        dispatch({
            type: SUMMARY_ERROR,
            payload: '다시 시도 부탁드립니다.'
        });
    }
};