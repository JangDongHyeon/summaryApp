import React from 'react';
import Container from '@material-ui/core/Container';
import Box from '@material-ui/core/Box';
import Header from './Haeder';
import Summary from './summary';
class App extends React.Component {
    render() {
        return (
            <Container maxWidth="lg">
                <Box my={2}>
                    <Header />
                    <Summary />
                </Box>
            </Container>
        );
    }
}

export default App;
